package com.pms.pojos;

public enum OrderStatus {
	PROCESS, COMPLETE;
}
